#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);
IZIN=$(curl -sS https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/ip | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo "IZIN DI TERIMA!!"
else
clear
figlet "Akses di tolak!! Silakan Hubungi Admin" | lolcat
exit 0
fi
cp /media/izzvpn/var.txt /tmp
clear
cp /root/izzvpn/var.txt /tmp
clear
rm -rf izzvpn
clear
apt update && apt upgrade -y
apt install python3 python3-pip -y
apt install sqlite3 -y
cd /media/
rm -rf izzvpn
clear
wget http://myrid.my.id/bot/izzvpn.zip
unzip izzvpn.zip
cd izzvpn
rm var.txt
clear
rm database.db
clear
pip3 install -r requirements.txt
pip install pillow
pip install speedtest-cli
pip3 install aiohttp
pip3 install paramiko
sldns=$(cat /root/nsdomain)
domain=$(cat /etc/xray/domain)
clear
echo -e ""
echo -e ""
echo "INSTALL BOT CREATE SSH via TELEGRAM"
read -e -p "[*] Input Your Id Telegram :" admin
read -e -p "[*] Input Your bot Telegram :" token
read -e -p "[*] Input username Telegram :" user
cat > /media/izzvpn/var.txt << END
ADMIN="$admin"
BOT_TOKEN="$token"
DOMAIN="$domain"
DNS="$sldns"
PUB="7fbd1f8aa0abfe15a7903e837f78aba39cf61d36f183bd604daa2fe4ef3b7b59"
OWN="$user"
SALDO="100000"
END
clear
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[44;97;1m          UZZ STORE VPN          [0m"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[44;97;1m     CREATE BOT SUCCESFULLY        \e[0m"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[96;1m Api Token     : $token"
echo -e "[96;1m ID Telegram   : $admin"
echo -e "[96;1m Domain vps    : $domain"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
echo -e "91;1m Wait in 4 second.....[0m"
sleep 4
clear
rm -f /usr/bin/nenen
echo -e '#!/bin/bash
cd /media/
python3 -m izzvpn' > /usr/bin/nenen
chmod 777 /usr/bin/nenen
cat > /etc/systemd/system/izzvpn.service << END
[Unit]
Description=Simple IZZVPN - @IZZVPN
After=network.target
[Service]
WorkingDirectory=/root
ExecStart=/usr/bin/nenen
Restart=always
[Install]
WantedBy=multi-user.target
END
systemctl daemon-reload
systemctl start izzvpn
systemctl enable izzvpn
clear
echo
echo
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[44;97;1m        DOWNLOAD ASSET BOT         \e[0m"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
wget -q -O /usr/bin/panelbot "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/panelbot.sh" && chmod +x /usr/bin/panelbot
wget -q -O /usr/bin/addnoobz "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/addnoobz.sh" && chmod +x /usr/bin/addnoobz
wget -q -O /media/log-install.txt "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/log-install.txt"
wget -q -O /usr/bin/add-vless "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/add-vless.sh" && chmod +x /usr/bin/add-vless
wget -q -O /usr/bin/addtr "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/addtr.sh" && chmod +x /usr/bin/addtr
wget -q -O /usr/bin/addws "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/addws.sh" && chmod +x /usr/bin/addws
wget -q -O /usr/bin/addss "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/addss.sh" && chmod +x /usr/bin/addss
wget -q -O /usr/bin/cek-ssh "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-ssh.sh" && chmod +x /usr/bin/cek-ssh
wget -q -O /usr/bin/cek-ss "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-ss.sh" && chmod +x /usr/bin/cek-ss
wget -q -O /usr/bin/cek-tr "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-tr.sh" && chmod +x /usr/bin/cek-tr
wget -q -O /usr/bin/cek-vless "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-vless.sh" && chmod +x /usr/bin/cek-vless
wget -q -O /usr/bin/cek-ws "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-ws.sh" && chmod +x /usr/bin/cek-ws
wget -q -O /usr/bin/del-vless "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/del-vless.sh" && chmod +x /usr/bin/del-vless
wget -q -O /usr/bin/cek-noobz "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-noobz.sh" && chmod +x /usr/bin/cek-noobz
wget -q -O /usr/bin/deltr "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/deltr.sh" && chmod +x /usr/bin/deltr
wget -q -O /usr/bin/delws "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/delws.sh" && chmod +x /usr/bin/delws
wget -q -O /usr/bin/delss "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/delss.sh" && chmod +x /usr/bin/delss
wget -q -O /usr/bin/renew-ss "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/renew-ss.sh" && chmod +x /usr/bin/renew-ss
wget -q -O /usr/bin/renewtr "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/renewtr.sh" && chmod +x /usr/bin/renewtr
wget -q -O /usr/bin/renewvless "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/renewvless.sh" && chmod +x /usr/bin/renewvless
wget -q -O /usr/bin/renewws "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/renewws.sh" && chmod +x /usr/bin/renewws
wget -q -O /usr/bin/cek-mws "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-mws.sh" && chmod +x /usr/bin/cek-mws
wget -q -O /usr/bin/cek-mvs "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-mvs.sh" && chmod +x /usr/bin/cek-mvs
wget -q -O /usr/bin/cek-mss "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-mss.sh" && chmod +x /usr/bin/cek-mss
wget -q -O /usr/bin/cek-mts "https://raw.githubusercontent.com/karimahahmad/sctun-uzzstore/main/limit/cek-mts.sh" && chmod +x /usr/bin/cek-mts
wget -q -O /usr/bin/addssh-bot "http://myrid.my.id/bot/addssh-bot" && chmod +x /usr/bin/addssh-bot
cp /tmp/var.txt /media/izzvpn
clear
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[44;97;1m          UZZ STORE VPN          [0m"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e "[44;97;1m       DOWNLOAD SUCCESFULLY        \e[0m"
echo -e "[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
echo -e ""
echo -e "[96;1m KETIK /menu : .menu : .crot : .gas DI BOT TELEGRAM ANDA [0m"
echo -e ""
rm /media/izzvpn.zip
exec bash
